//console.log('Ola');

//const valorA = 5;
//const valorB = 6;
//console.log('a soma dos valores é:', valorA+valorB);

//const peso = 57;
//const altura = 1.54;
//console.log(peso/(altura*altura));

//const aresta = 3;
//console.log(aresta*aresta*aresta);

//const mediaConsumo = 12;
//const tempo = 10;
//const velocidade = 85;
//const consumo = console.log((velocidade*tempo)/mediaConsumo);
//console.log(consumo);

const var1 = 5; 
const var2 = 6;
const var3 = 7;
const var4 = 8;

valorX = var1*var2;
valorY = var3*var4;

console.log(valorX-valorY);















 
