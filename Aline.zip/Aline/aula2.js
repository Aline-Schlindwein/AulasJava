/*
const varA = 3;
const varB = 4;
const varC = 5.2;

//questão a:
const triangulo = console.log((varA*varC)/2);

//questão b:
const circulo = console.log(3.14*(varC*varC));

//questão c:
const trapezio = console.log(((varA+varB)*varC)/2);

//questão d:
const quadrado = console.log(varB*varB);

//questão e:
const retangulo = console.log(varA*varB);
*/

/*
const idade = 16;

if(idade >=18){
    console.log('acesso permitido');
}else if(idade==17){
    console.log('falta apenas um ano para ter acesso');
}
else {
    console.log('acesso negado');
}
*/

/*
const numero = 5;

if(numero %2 == 0){
    console.log('numero par');
}
else {
    console.log('numero impar');
}
*/

/*
const peso = 59;
const altura = 1.54;
const IMC = (peso/(altura*altura));

if(IMC < 18.5){
    console.log('magreza');
}
else if(IMC >= 18.5 && IMC <= 24.9){
    console.log('normal');
} 
else if(IMC >= 25 && IMC <= 29.9){
    console.log('sobrepeso');
}
else if(IMC >= 30 && IMC <= 34.9){
    console.log('obesidade 1');
}
else if(IMC >= 35 && IMC <= 39.9){
    console.log('obesidade 2');
}
else if(IMC >=40){
    console.log('obesidade 3');
}
*/

/*
const salario = 2001.00;
const var1 = ((salario*15)/100);
const var2 = ((salario*12)/100);
const var3 = ((salario*10)/100);
const var4 = ((salario*7)/100);
const var5 = ((salario*4)/100);


if(salario <= 400.00){
    console.log('novo salario',salario+var1);
    console.log('reajuste ganho', var1);
    console.log('em percentual: 15%');
}
else if(salario >= 400.01 && salario <= 800.00){
    console.log('novo salario',salario+var2);
    console.log('reajuste ganho', var2);
    console.log('em percentual: 12%');
}
else if(salario >= 800.01 && salario <= 1200.00){
    console.log('novo salario',salario+var3); 
    console.log('reajuste ganho', var3);
    console.log('em percentual: 10%');
} 
else if(salario >= 1200.01 && salario <= 2000.00) {
    console.log('novo salario',salario+var4);
    console.log('reajuste ganho', var4);
    console.log('em percentual: 7%');
} 
else if(salario >= 2000.00){
    console.log('novo salario',salario+var5);
    console.log('reajuste ganho', var5);
    console.log('em percentual: 4%');
}
*/

const mes = 5;

switch (mes){
    case 1:
        console.log("janeiro")
        break;
    case 2:
        console.log("fevereiro")
        break;
    case 3:
        console.log("março")
        break;
    default:
        console.log("mes inexistente"); 
 
}







